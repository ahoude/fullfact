## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, warning = FALSE, message= FALSE, comment = "#>")

## ----package-data-------------------------------------------------------------
library("fullfact")  
data(chinook_survival)
head(chinook_survival)

## ----binary-------------------------------------------------------------------
chinook_survival2<- buildBinary(dat=chinook_survival,copy=c(1:6,9),one="alive",zero="dead")
rm(chinook_survival) #remove original
head(chinook_survival2)
#Multinomial example
#>chinook_survival$total<- chinook_survival$alive + chinook_survival$dead
#>chinook_survival3<- buildMulti(dat=chinook_survival,copy=c(1:6,9),multi=list(c(2,1,0),
#>c("total","alive","dead")))
#>head(chinook_survival3)

## ----observed-vc--------------------------------------------------------------
survival_mod2<- observGlmer2(observ=chinook_survival2,dam="dam",sire="sire",response="status",
fam_link=binomial(logit),position="tray")
survival_mod2

## ----power-analysis-----------------------------------------------------------
#full
#>powerGlmer2(varcomp=c(0.7880,0.1667,0.1671,0.0037),nval=c(11,11,300,2420),
#>fam_link=binomial(logit),position=15) 
#2 simulations
powerGlmer2(varcomp=c(0.7880,0.1667,0.1671,0.0037),nval=c(11,11,300,2420),
fam_link=binomial(logit),position=15,nsim=2) 

#Block examples using 8 dams, 8 sires (as four 2x2 blocks), and 20 offspring per family
#>powerGlmer2(varcomp=c(0.7880,0.1667,0.1671,0.0037),nval=c(8,8,20,4),fam_link=binomial(logit),
#>block=c(2,2)) 
#>powerGlmer2(varcomp=c(0.7880,0.1667,0.1671,0.0037,0.0037),nval=c(8,8,20,40,4),
#>fam_link=binomial(logit),position=8,block=c(2,2)) #with position

## ----power-analysis2----------------------------------------------------------
#full
#>powerGlmer2(varcomp=c(0.7880,0.1667,0.1671,0.0037),nval=c(7,7,300,980),
#>fam_link=binomial(logit),position=15)
#2 simulations
powerGlmer2(varcomp=c(0.7880,0.1667,0.1671,0.0037),nval=c(7,7,300,980),
fam_link=binomial(logit),position=15,nsim=2)

## ----resample, eval=FALSE-----------------------------------------------------
#  #>resampRepli(dat=chinook_survival2,copy=c(1,4:8),family="family",replicate="repli",iter=1000) #full
#  #>resampFamily(dat=chinook_survival2,copy=c(1,4:8),family="family",iter=1000) #family only
#  resampRepli(dat=chinook_survival2,copy=c(1,4:8),family="family",replicate="repli",iter=5) #5 iterations

## ----boot-vc------------------------------------------------------------------
#>survival_datR<- read.csv("resamp_datR.csv") #1000 iterations
#>survival_rcomp2<- resampGlmer2(resamp=survival_datR,dam="dam",sire="sire",response="status",
#>fam_link=binomial(logit),position="tray",start=1,end=1000) #full
data(chinook_resampS) #5 iterations
head(chinook_resampS)
survival_rcomp2<- resampGlmer2(resamp=chinook_resampS,dam="dam",sire="sire",response="status",
fam_link=binomial(logit),position="tray",start=1,end=2)
survival_rcomp2[1:2,]

## ----boot-ci------------------------------------------------------------------
#>ciMANA(comp=survival_rcomp2,position="tray") #full
data(chinook_bootS) #similar to survival_rcomp2 1000 models, but has no tray
ciMANA2(comp=chinook_bootS,position="Total")

## ----boot-ci-bias-------------------------------------------------------------
#bias only
ciMANA2(comp=chinook_bootS,bias=c(0.6655,0.6692,0.6266,4.4166),position="Total")
#full, observGlmer2 components
#>ciMANA2(comp=survival_rcomp2,bias=c(0.6655,0.6692,0.6266,0.0037),position="tray") 

## ----boot-ci-bias-accel-------------------------------------------------------
data(chinook_jackS) #delete-30
#bias and acceleration
ciMANA2(comp=chinook_bootS,bias=c(0.6655,0.6692,0.6266,4.4166),position="Total",
accel=chinook_jackS) 
#full, observGlmer2 components
#>ciMANA2(comp=survival_rcomp1,bias=c(0.6655,0.6692,0.6266,0.0037),position="tray",
#>accel=survival_jack1)

## ----jack-vc-d----------------------------------------------------------------
#full
#>survival_jack2<- JackGlmer2(observ=chinook_survival2,dam="dam",sire="sire",response="status",
#>fam_link=binomial(logit),position="tray",size=30)
#first 2
survival_jack2<- JackGlmer2(observ=chinook_survival2,dam="dam",sire="sire",response="status",
fam_link=binomial(logit),position="tray",size=30,first=2)
survival_jack2[1:2,]

## ----jack-ci------------------------------------------------------------------
data(chinook_jackS) #similar to survival_jack2, all observations, but has no tray
ciJack2(comp=chinook_jackS,position="Residual",full=c(0.6655,0.6692,0.6266,4.4166,3.2899))
#full, all observations, observGlmer2 components
#>ciJack2(comp=survival_jack2,position="tray",full=c(0.6655,0.6692,0.6266,4.4166,0.0037)) 

## ----barplot, fig.width=7, fig.height=10--------------------------------------
survival_ci<- ciJack2(comp=chinook_jackS,position="Residual",
full=c(0.6655,0.6692,0.6266,4.4166,3.2899))
oldpar<- par(mfrow=c(2,1))
barMANA(ci_dat=survival_ci) #basic, top
barMANA(ci_dat=survival_ci,bar_len=0.3,yunit=4,ymax=20,cex_ylab=1.3) #modified, bottom

## ----barplot-comb, fig.width=7, fig.height=5----------------------------------
survival_ci1<- ciJack2(comp=chinook_jackS,position="Residual",
full=c(0.6655,0.6692,0.6266,4.4166,3.2899),trait="survival_1")
survival_ci2<- ciJack2(comp=chinook_jackS,position="Residual",
full=c(0.6655,0.6692,0.6266,4.4166,3.2899),trait="survival_2")
comb_bar<- list(raw=rbind(survival_ci1$raw,survival_ci2$raw),
percentage=rbind(survival_ci1$percentage,survival_ci2$percentage)) 
barMANA(ci_dat=comb_bar,bar_len=0.3,yunit=4,ymax=20,cex_ylab=1.3)

## ----boxplot, fig.width=7, fig.height=10--------------------------------------
oldpar<- par(mfrow=c(2,1))
boxMANA(comp=chinook_bootS) #from resampGlmer2, basic, top 
boxMANA(comp=chinook_bootS,yunit=2,ymin=10,ymax=22,cex_ylab=1.3,leg="topleft") #modified, bottom

## ----boxplot-comb, fig.width=7, fig.height=5----------------------------------
chinook_bootS1<- chinook_bootS; chinook_bootS2<- chinook_bootS #from resampGlmer2
chinook_bootS1$trait<- "survival_1"; chinook_bootS2$trait<- "survival_2"
comb_boot<- rbind(chinook_bootS1,chinook_bootS2)
comb_boot$trait<- as.factor(comb_boot$trait)
boxMANA(comb_boot,yunit=2,ymin=10,ymax=22,cex_ylab=1.3,leg="topleft")

