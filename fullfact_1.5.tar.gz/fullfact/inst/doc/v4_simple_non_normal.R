## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, warning = FALSE, message= FALSE, comment = "#>")

## ----package-data-------------------------------------------------------------
library("fullfact")  
data(chinook_survival)
head(chinook_survival)

## ----binary-------------------------------------------------------------------
chinook_survival2<- buildBinary(dat=chinook_survival,copy=c(1:6,9),one="alive",zero="dead")
rm(chinook_survival) #remove original
head(chinook_survival2)
#Multinomial example
#>chinook_survival$total<- chinook_survival$alive + chinook_survival$dead
#>chinook_survival3<- buildMulti(dat=chinook_survival,copy=c(1:6,9),multi=list(c(2,1,0),
#>c("total","alive","dead")))
#>head(chinook_survival3)

## ----observed-vc--------------------------------------------------------------
survival_mod1<- observGlmer(observ=chinook_survival2,dam="dam",sire="sire",response="status",
fam_link=binomial(logit))
survival_mod1

## ----power-analysis-----------------------------------------------------------
#full
#>powerGmer(varcomp=c(0.7930,0.1664,0.1673),nval=c(11,11,300),fam_link=binomial(logit)) 
#2 simulations
powerGlmer(varcomp=c(0.7930,0.1664,0.1673),nval=c(11,11,300),fam_link=binomial(logit),nsim=2) 

## ----power-analysis2----------------------------------------------------------
#full
#>powerGlmer(varcomp=c(0.7930,0.1664,0.1673),nval=c(7,7,300),fam_link=binomial(logit))
#2 simulations
powerGlmer(varcomp=c(0.7930,0.1664,0.1673),nval=c(7,7,300),fam_link=binomial(logit),nsim=2)

## ----resample, eval=FALSE-----------------------------------------------------
#  #>resampRepli(dat=chinook_survival2,copy=c(1,4:8),family="family",replicate="repli",iter=1000) #full
#  #>resampFamily(dat=chinook_survival2,copy=c(1,4:8),family="family",iter=1000) #family only
#  resampRepli(dat=chinook_survival2,copy=c(1,4:8),family="family",replicate="repli",iter=2) #2 iterations

## ----boot-vc------------------------------------------------------------------
#>survival_datR<- read.csv("resamp_datR.csv") #1000 iterations
#>survival_rcomp1<- resampGlmer(resamp=survival_datR,dam="dam",sire="sire",response="status",
#>fam_link=binomial(logit),start=1,end=1000) #full
data(chinook_resampS) #5 iterations
head(chinook_resampS)
survival_rcomp1<- resampGlmer(resamp=chinook_resampS,dam="dam",sire="sire",response="status",
fam_link=binomial(logit),start=1,end=2)
survival_rcomp1[1:2,]

## ----boot-ci------------------------------------------------------------------
#>ciMANA(comp=survival_rcomp1) #full
data(chinook_bootS) #same as survival_rcomp1 1000 models
ciMANA(comp=chinook_bootS)

## ----boot-ci-bias-------------------------------------------------------------
ciMANA(comp=chinook_bootS,bias=c(0.6655,0.6692,0.6266)) #bias only
#>ciMANA(comp=survival_rcomp1,bias=c(0.6655,0.6692,0.6266)) #full

## ----boot-ci-bias-accel-------------------------------------------------------
data(chinook_jackS) #delete-30
ciMANA(comp=chinook_bootS,bias=c(0.6655,0.6692,0.6266),accel=chinook_jackS) #bias and acceleration
#>ciMANA(comp=survival_rcomp1,bias=c(0.6655,0.6692,0.6266),accel=survival_jack1) #full

## ----jack-vc-d----------------------------------------------------------------
#full
#>survival_jack1<- JackGlmer(observ=chinook_survival2,dam="dam",sire="sire",response="status",
#>fam_link=binomial(logit),size=30)
#first 2
survival_jack1<- JackGlmer(observ=chinook_survival2,dam="dam",sire="sire",response="status",
fam_link=binomial(logit),size=30,first=2)
survival_jack1[1:2,]

## ----jack-ci------------------------------------------------------------------
data(chinook_jackS) #same as survival_jack1, all observations, delete-30
ciJack(comp=chinook_jackS,full=c(0.6655,0.6692,0.6266,4.4166))
#full, all observations
#>ciJack(comp=survival_jack1,full=c(0.6655,0.6692,0.6266,4.4166)) 

## ----barplot, fig.width=7, fig.height=10--------------------------------------
survival_ci<- ciJack(comp=chinook_jackS,full=c(0.6655,0.6692,0.6266,4.4166))
oldpar<- par(mfrow=c(2,1))
barMANA(ci_dat=survival_ci) #basic, top
barMANA(ci_dat=survival_ci,bar_len=0.3,yunit=4,ymax=20,cex_ylab=1.3) #modified, bottom

## ----barplot-comb, fig.width=7, fig.height=5----------------------------------
survival_ci1<- ciJack(comp=chinook_jackS,full=c(0.6655,0.6692,0.6266,4.4166),trait="survival_1")
survival_ci2<- ciJack(comp=chinook_jackS,full=c(0.6655,0.6692,0.6266,4.4166),trait="survival_2")
comb_bar<- list(raw=rbind(survival_ci1$raw,survival_ci2$raw),
percentage=rbind(survival_ci1$percentage,survival_ci2$percentage)) 
barMANA(ci_dat=comb_bar,bar_len=0.3,yunit=4,ymax=20,cex_ylab=1.3)

## ----boxplot, fig.width=7, fig.height=10--------------------------------------
oldpar<- par(mfrow=c(2,1))
boxMANA(comp=chinook_bootS) #from resampGlmer, basic, top 
boxMANA(comp=chinook_bootS,yunit=2,ymin=10,ymax=22,cex_ylab=1.3,leg="topleft") #modified, bottom

## ----boxplot-comb, fig.width=7, fig.height=5----------------------------------
chinook_bootS1<- chinook_bootS; chinook_bootS2<- chinook_bootS #from resampGlmer
chinook_bootS1$trait<- "survival_1"; chinook_bootS2$trait<- "survival_2"
comb_boot<- rbind(chinook_bootS1,chinook_bootS2)
comb_boot$trait<- as.factor(comb_boot$trait)
boxMANA(comb_boot,yunit=2,ymin=10,ymax=22,cex_ylab=1.3,leg="topleft")

