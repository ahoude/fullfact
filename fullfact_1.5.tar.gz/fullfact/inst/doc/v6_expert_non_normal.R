## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, warning = FALSE, message= FALSE, comment = "#>")

## ----package-data-------------------------------------------------------------
library("fullfact")  
data(chinook_survival)
head(chinook_survival)

## ----binary-------------------------------------------------------------------
chinook_survival2<- buildBinary(dat=chinook_survival,copy=c(1:6,9),one="alive",zero="dead")
rm(chinook_survival) #remove original
head(chinook_survival2)
#Multinomial example
#>chinook_survival$total<- chinook_survival$alive + chinook_survival$dead
#>chinook_survival3<- buildMulti(dat=chinook_survival,copy=c(1:6,9),multi=list(c(2,1,0),
#>c("total","alive","dead")))
#>head(chinook_survival3)

## ----observed-vc--------------------------------------------------------------
#>survival_mod3<- observGlmer3(observ=chinook_survival2,dam="dam",sire="sire",response="status",
#>remain="egg_size + (1|tray)",fam_link=binomial(logit),iter=1000) #full
survival_mod3<- observGlmer3(observ=chinook_survival2,dam="dam",sire="sire",response="status",
remain="egg_size + (1|tray)",fam_link=binomial(logit),iter=2)
survival_mod3

## ----power-analysis-----------------------------------------------------------
#Reworking the Chinook salmon data set to contain only integers for `design`
#dam ID, sire ID, family ID
desn0<- data.frame(dam=rep(1:11,each=11),sire=rep(1:11,11),family=1:(11*11))
#replicate for offspring sample size (300)
desn<- do.call("rbind", replicate(300,desn0,simplify=F)); rm(desn0) 
desn$tray<- rep(1:15,each=nrow(desn)/15) #equal number of offspring per tray 
desn$tray<- sample(desn$tray,nrow(desn)) #shuffle tray numbers
desn$egg_size<- desn$dam #egg size is related to dam
head(desn)
#full with LR
#>powerGlmer3(var_rand=c(0.6497,0.1660,0.1672,0.0036),n_rand=c(11,11,121,15),var_fix=0.1386,
#>n_fix=11,design=desn,remain="(1|tray) + egg_size",fam_link=binomial(logit)) 
#full with PB and 1000 iterations
#>powerGmer3(var_rand=c(0.6497,0.1660,0.1672,0.0036),n_rand=c(11,11,121,15),var_fix=0.1386,
#>n_fix=11,design=desn,remain="(1|tray) + egg_size",fam_link=binomial(logit),
#>ftest="PB",iter=1000)
#2 simulations with LR
powerGlmer3(var_rand=c(0.6497,0.1660,0.1672,0.0036),n_rand=c(11,11,121,15),var_fix=0.1386,
n_fix=11,design=desn,remain="(1|tray) + egg_size",fam_link=binomial(logit),nsim=2) 

## ----power-analysis2----------------------------------------------------------
#dam ID, sire ID, family ID
desn0_2<- data.frame(dam=rep(1:7,each=7),sire=rep(1:7,7),family=1:(7*7))
#replicate for offspring sample size (300)
desn_2<- do.call("rbind", replicate(300,desn0_2,simplify=F)); rm(desn0_2) 
desn_2$tray<- rep(1:15,each=nrow(desn_2)/15) #equal number of offspring per tray 
desn_2$tray<- sample(desn_2$tray,nrow(desn_2)) #shuffle tray numbers
desn_2$egg_size<- desn_2$dam #egg size is related to dam
#full with LR
#>powerGlmer3(var_rand=c(0.6497,0.1660,0.1672,0.0036),n_rand=c(7,7,49,15),var_fix=0.1386,
#>n_fix=11,design=desn_2,remain="(1|tray) + egg_size",fam_link=binomial(logit)) 
#full with PB and 1000 iterations
#>powerGmer3(var_rand=c(0.6497,0.1660,0.1672,0.0036),n_rand=c(7,7,49,15),var_fix=0.1386,
#>n_fix=11,design=desn_2,remain="(1|tray) + egg_size",fam_link=binomial(logit),
#>ftest="PB",iter=1000)
#2 simulations with LR
powerGlmer3(var_rand=c(0.6497,0.1660,0.1672,0.0036),n_rand=c(7,7,49,15),var_fix=0.1386,
n_fix=11,design=desn_2,remain="(1|tray) + egg_size",fam_link=binomial(logit),nsim=2) 

## ----resample, eval=FALSE-----------------------------------------------------
#  #>resampRepli(dat=chinook_survival2,copy=c(1,4:8),family="family",replicate="repli",iter=1000) #full
#  #>resampFamily(dat=chinook_survival2,copy=c(1,4:8),family="family",iter=1000) #family only
#  resampRepli(dat=chinook_survival2,copy=c(1,4:8),family="family",replicate="repli",iter=2) #2 iterations

## ----boot-vc------------------------------------------------------------------
#>survival_datR<- read.csv("resamp_datR.csv") #1000 iterations
#>survival_rcomp3<- resampGlmer3(resamp=survival_datR,dam="dam",sire="sire",response="status",
#>remain="egg_size# + (1|tray#)",fam_link=binomial(logit),start=1,end=1000) #full
data(chinook_resampS) #5 iterations
head(chinook_resampS)
survival_rcomp3<- resampGlmer3(resamp=chinook_resampS,dam="dam",sire="sire",response="status",
remain="egg_size# + (1|tray#)",fam_link=binomial(logit),start=1,end=2)
survival_rcomp3[1:2,]

## ----boot-ci------------------------------------------------------------------
#>ciMANA3(comp=survival_rcomp3,remain=c("tray","Fixed")) #full, with egg size as Fixed
data(chinook_bootS) #similar to survival_rcomp3 1000 models, but has no tray or Fixed
ciMANA3(comp=chinook_bootS,remain=c("Total"))

## ----boot-ci-bias-------------------------------------------------------------
#bias only
ciMANA3(comp=chinook_bootS,remain=c("Total"),bias=c(0.6655,0.6692,0.6266,4.4166))
#full
#>ciMANA3(comp=survival_rcomp3,remain=c("tray","Fixed"),bias=c(0.6655,0.6692,0.6266,0.0036,0.1386)) 

## ----boot-ci-bias-accel-------------------------------------------------------
data(chinook_jackS) #delete-30
#bias and acceleration
ciMANA3(comp=chinook_bootS,remain=c("Total"),bias=c(0.6655,0.6692,0.6266,4.4166),
accel=chinook_jackS)
#full
#>ciMANA3(comp=survival_rcomp3,remain=c("tray","Fixed"),bias=c(0.6655,0.6692,0.6266,0.0036,0.1386),
#>accel=survival_jack3) 

## ----jack-vc-d----------------------------------------------------------------
#full
#>survival_jack3<- JackGlmer3(observ=chinook_survival2,dam="dam",sire="sire",response="status",
#>remain="egg_size + (1|tray)",fam_link=binomial(logit),size=30)
#first 2
survival_jack3<- JackGlmer3(observ=chinook_survival2,dam="dam",sire="sire",response="status",
remain="egg_size + (1|tray)",fam_link=binomial(logit),size=30,first=2)
survival_jack3[1:2,]

## ----jack-ci------------------------------------------------------------------
data(chinook_jackS) #same as survival_jack3, all observations, delete-30
ciJack3(comp=chinook_jackS,remain=c("Residual"),full=c(0.6655,0.6692,0.6266,4.4166,3.2899))
#full, all observations
#>ciJack3(comp=survival_jack3,remain=c("tray","Fixed"),full=c(0.6655,0.6692,0.6266,4.4166,0.0036,
#>0.1386)) 

## ----barplot, fig.width=7, fig.height=10--------------------------------------
survival_ci<- ciJack3(comp=chinook_jackS,remain=c("Residual"),full=c(0.6655,0.6692,0.6266,
4.4166,3.2899))
oldpar<- par(mfrow=c(2,1))
barMANA(ci_dat=survival_ci) #basic, top
barMANA(ci_dat=survival_ci,bar_len=0.3,yunit=4,ymax=20,cex_ylab=1.3) #modified, bottom

## ----barplot-comb, fig.width=7, fig.height=5----------------------------------
survival_ci1<- ciJack3(comp=chinook_jackS,remain=c("Residual"),full=c(0.6655,0.6692,0.6266,
4.4166,3.2899),trait="survival_1")
survival_ci2<- ciJack3(comp=chinook_jackS,remain=c("Residual"),full=c(0.6655,0.6692,0.6266,
4.4166,3.2899),trait="survival_2")
comb_bar<- list(raw=rbind(survival_ci1$raw,survival_ci2$raw),
percentage=rbind(survival_ci1$percentage,survival_ci2$percentage)) 
barMANA(ci_dat=comb_bar,bar_len=0.3,yunit=4,ymax=20,cex_ylab=1.3)

## ----boxplot, fig.width=7, fig.height=10--------------------------------------
oldpar<- par(mfrow=c(2,1))
boxMANA(comp=chinook_bootS) #from resampGlmer3, basic, top 
boxMANA(comp=chinook_bootS,yunit=2,ymin=10,ymax=22,cex_ylab=1.3,leg="topleft") #modified, bottom

## ----boxplot-comb, fig.width=7, fig.height=5----------------------------------
chinook_bootS1<- chinook_bootS; chinook_bootS2<- chinook_bootS #from resampGlmer3
chinook_bootS1$trait<- "survival_1"; chinook_bootS2$trait<- "survival_2"
comb_boot<- rbind(chinook_bootS1,chinook_bootS2)
comb_boot$trait<- as.factor(comb_boot$trait)
boxMANA(comb_boot,yunit=2,ymin=10,ymax=22,cex_ylab=1.3,leg="topleft")

